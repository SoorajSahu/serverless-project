
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sunday',
  applicationName: 'aws-node-express-api-project',
  appUid: 'jstPRc708XFF7dsS5R',
  orgUid: 'd6a0cffd-d9a7-43e7-b824-36ac73ce63c6',
  deploymentUid: 'd95eb947-623b-4479-a208-2fa2a688d67d',
  serviceName: 'aws-node-express-api-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-express-api-project-dev-hello', timeout: 60 };

try {
  const userHandler = require('./src/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.genrateRandomeNumber, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}